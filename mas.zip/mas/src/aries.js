const aries = () => { 
	return `       
Aries (21 Maret – 20 April)

Aries (♈) /ˈɛəriːz/ (yang berarti "Domba") adalah rasi Zodiak pertama, yang mencakup 30 derajat pertama bujur langit (0°≤ λ <30°). Di bawah zodiak tropis, Matahari transit di rasi ini umumnya antara 20 Maret sampai 20 April setiap tahunnya. Durasi waktu ini persis bulan pertama Kalender Persia (Farvardin). Di bawah zodiak sidereal, matahari saat transit Aries dari 15 April - 15 Mei (kurang-lebih). Simbol domba yang didasarkan pada Chrysomallus, domba terbang.
Tergantung pada sistem yang digunakan, individu yang lahir pada tanggal tersebut, dapat disebut Arian atau Ariens . Aries adalah rasi api pertama di zodiak, rasi api lainnya adalah Leo dan sagitarius
`
}
exports.aries = aries