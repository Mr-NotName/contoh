const nsfwmenu = (prefix) => { 
	return `
╭┈─────𝙵𝙸𝚃𝚄𝚁 𝙽𝚈𝙰 𝙺𝙰𝙺
╰─❁۪۪
╰─➤ *${prefix}randomhentai*
╰─➤ *${prefix}hentai*
╰─➤ *${prefix}nsfwblowjob*
╰─➤ *${prefix}nsfwtrap*
╰─➤ *${prefix}nsfwneko*
╰─➤ *${prefix}loli*
╰─➤ *${prefix}nsfwloli*
╰─➤ *${prefix}bokep*
╰─➤ *${prefix}kodenuklir2*
╰─➤ *${prefix}randomanime*
╰─➤ *${prefix}cry*
╰─➤ *${prefix}kiss*
╰─➤ *${prefix}randomhug*
╰─➤ *${prefix}nekonime*
╰─➤ *${prefix}waifu*
╰─➤ *${prefix}waifu2*
╰─➤ *${prefix}kodenuklir*
╰─➤ *${prefix}nekopoi*
╭┈────𝚝𝚑𝚊𝚗𝚡 𝚝𝚘 𝚖𝚊𝚜𝚕𝚎𝚗𝚝 𝚢𝚝
╰─❁۪۪`
}
exports.nsfwmenu = nsfwmenu